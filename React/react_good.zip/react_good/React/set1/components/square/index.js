import square from "./square"
export default square;
