import game from "./game"
export default game;
