import redux1 from "./redux1"
export default redux1;
