import areaform from "./areaform"
export default areaform;
